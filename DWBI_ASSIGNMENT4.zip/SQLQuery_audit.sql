USE [assignment1]
GO

/****** Object:  Table [dbo].[auditTable]    Script Date: 2/12/2019 11:49:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[auditTable](
	[Package ID] [uniqueidentifier] NULL,
	[Package name] [nvarchar](64) NULL,
	[Execution instance GUID] [uniqueidentifier] NULL
) ON [PRIMARY]
GO


