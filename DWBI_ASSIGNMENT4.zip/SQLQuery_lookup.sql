USE [assignment1]
GO

/****** Object:  Table [dbo].[lookup]    Script Date: 2/12/2019 11:50:47 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[lookup](
	[Copy of Part D Prescribers] [numeric](38, 0) NULL,
	[Copy of Part D Opioid Prescribers] [numeric](38, 0) NULL,
	[Copy of Opioid Claims] [numeric](38, 0) NULL,
	[Copy of Extended Release Opioid Claims] [numeric](38, 0) NULL,
	[Copy of Overall Claims] [numeric](38, 0) NULL
) ON [PRIMARY]
GO


